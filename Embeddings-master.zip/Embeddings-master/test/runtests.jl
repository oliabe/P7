using Test
using Embeddings 

# Set up some artificial data
x = LinRange(0,1,100)
y = LinRange(0,1,100)

@testset "SequenceEmbeddings" begin
    Y = SequenceEmbedding(y)
    Y⁺ = SequenceEmbedding(y, -5, 5)    

    # Using the standard endpoints  
    @test Y[0] == y[1]
    @test Y[end + 1] == y[end]
    @test all(Y .== y)

    # Using the customized endpoints
    @test Y⁺[0] == -5
    @test Y⁺[end + 1] == 5
    @test all(Y⁺ .== y)
end

@testset "CadlagEmbeddings" begin
    f = CadlagEmbedding(y,x)
    f⁺ = CadlagEmbedding(y,x; lower = -5)
    i = rand(2:99)
    ε = 1e-5

    # Test the standard embedding
    @test all(f.(x) .== y)
    @test f(x[i] + ε) == y[i]
    @test f(x[i] - ε) == y[i-1]

    # Test the custom embedding
    @test all(f⁺.(x) .== y)
    @test f⁺(x[i] + ε) == y[i]
    @test f⁺(x[i] - ε) == y[i-1]
    @test f⁺(x[1] - ε) == -5
end

@testset "CagladEmbeddings" begin
    f = CagladEmbedding(y,x)
    i = rand(2:99)
    ε = 1e-5
    
    @test f(x[i] + ε) == y[i]
    @test f(x[i] - ε) == y[i-1]
end


@testset "LinearEmbeddings" begin
    f = LinearEmbedding(y,x)
    i = rand(2:99)
    ε = 1e-5
    α = ε/(x[i+1] - x[i])

    @test all(f.(x) .≈ y)
    @test f(x[i]) < f(x[i] + ε) < f(x[i+1])
    @test f(x[i] + ε) == α*y[i+1] + (1-α)*y[i]
end

