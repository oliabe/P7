# Bijections 
A function between two set $X$ and $Y$ is said to be bijective if it is injective and surjective. That is, given a function $f:X \to Y$ we have 

```math 
\forall x, x^\prime \in X: f(x) = f(x^\prime) \implies x = x^\prime,
``` 

and

```math
\forall y \in Y \exists x \in X: f(x) = y.
```

Given these two assumptions, an inverse function exists. To some extent, it means that the sets $X$ and $Y$ are the "same", since each element of either set can be uniquely identified in the other. 

### TimeBijector
Notice that time is, by construction, bijective with the real numbers. There are many different bijections and we provide a method for constructing such mappings. The constructors are detailed below: 

```julia
ϕ = TimeBijector(s::DateTime,t::DateTime,x::Real,y::Real) # s < t, x < y. Constructs the bijector such that ϕ(s) = x and ϕ(t) = y 
ϕ = TimeBijector(s::DateTime,t::DateTime) # s < t. Constructs the bijector such that ϕ(s) = 0 and ϕ(t) = 1. 
```

Now, methods are defined both ways, that is 

```julia
ϕ(t::DateTime) 
ϕ(x::Real)

ϕ(ϕ(t)) = t
ϕ(ϕ(x)) = x 
```

