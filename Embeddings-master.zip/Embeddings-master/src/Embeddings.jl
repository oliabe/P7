module Embeddings
using Plots
using Dates

# Sequence Embeddings 
include("SequenceEmbeddings/SequenceEmbedding.jl")

# Simple Embeddings 
include("SimpleEmbeddings/SimpleEmbedding.jl")

# Linear Embeddings 
include("LinearEmbeddings/LinearEmbedding.jl")

# Bijections 
include("Bijections/TimeBijections.jl")


export 
    SequenceEmbedding,
    SimpleEmbedding,
    CadlagEmbedding,
    CagladEmbedding, 
    LinearEmbedding,
    TimeBijector

end 
