# Embeddings: 
The following methods and embeddings are currently implemented: 

 - [Bijections](https://github.com/TokeZinn/Embeddings/tree/master/src/Bijections)
 - [SequenceEmbeddings](https://github.com/TokeZinn/Embeddings/tree/master/src/SequenceEmbeddings)
 - [LinearEmbedding](https://github.com/TokeZinn/Embeddings/tree/master/src/LinearEmbeddings)
 - [SimpleEmbedding](https://github.com/TokeZinn/Embeddings/tree/master/src/SimpleEmbeddings)

Note that, not all README's contain examples, but please refer to the tests or the example in the [main directory](https://github.com/TokeZinn/Embeddings/).
