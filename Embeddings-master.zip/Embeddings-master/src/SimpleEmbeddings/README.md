# Simple Functions 
A [simple function](https://en.wikipedia.org/wiki/Simple_function) is a function of the form 

```math
f(t) = \sum_{i=1}^n y_i\mathbb{I}_{A_i}(t), \quad n\in\mathbb{N},
```
where $\{y_i\}_{i=1}^N \subset \mathbb{R}$ (or some suitable other space) and $\{A_i\}_{i=1}^n$ are disjoint subsets of $\mathbb{R}$. 

### CadlagEmbedding
A [càdlàg](https://en.wikipedia.org/wiki/C%C3%A0dl%C3%A0g) embedding is an embedding of the dataset $\{(y_i, t_i)\}_{i=1}^n$ into the space of right continuous piecewise constant function with left limits identified with the function

```math
f(t) = a\mathbb{I}_{(-\infty, t_1)}(t) + \sum_{i = 1}^{N-1} y_i \mathbb{I}_{[t_i, t_{i+1})}(t) + y_n\mathbb{I}_{[t_n, \infty)}(t).
```

### CagladEmbedding
Conversely, a càglàd embedding is an embedding of the dataset $\{(y_i, t_i)\}_{i=1}^n$ into the space of right continuous piecewise constant function with left limits identified with the function

```math
f(t) = a\mathbb{I}_{(-\infty, t_1]}(t) + \sum_{i = 1}^{N-1} y_i \mathbb{I}_{(t_i, t_{i+1}]}(t) + y_n\mathbb{I}_{(t_n, \infty)}(t).
```
