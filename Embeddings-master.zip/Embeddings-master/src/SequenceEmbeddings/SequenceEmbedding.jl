import Base:
    getindex,
    size,
    setindex!,
    show,
    issorted,
    length

abstract type AbstractSequenceEmbedding{N,R} <: AbstractVector{R} end

struct SequenceEmbedding{N,R} <: AbstractSequenceEmbedding{N,R}
    inner::AbstractVector{R}
    lower::R
    upper::R
end

function getindex(S::AbstractSequenceEmbedding{N,R}, i::Int) where {N,R}
    if 1 ≤ i ≤ N
        return S.inner[i]
    elseif i > N 
        return S.upper
    else
        return S.lower
    end
end

getindex(S::AbstractSequenceEmbedding{N,R}, i::UnitRange{<:Int}) where {N,R} = R[S[j] for j in i] 
size(S::AbstractSequenceEmbedding) = size(S.inner)
setindex!(S::AbstractSequenceEmbedding, X, I::Vararg{<:Int}) = S.inner[I...] = X
function show(io::IO, ::MIME"text/plain", S::AbstractSequenceEmbedding)
    summary(io, S)
    println("")
    Base.print_matrix(io, S.inner)
end
issorted(S::AbstractSequenceEmbedding) = issorted([S.lower, S.inner..., S.upper])
length(S::AbstractSequenceEmbedding) = length(S.inner)

# Constructors
function SequenceEmbedding(x::AbstractVector{R}, lower::Q = x[1], upper::T = x[end]) where {R,Q,T} 
    S = promote_type(R,Q,T)

    lower = S == Q ? lower : S(lower)
    upper = S == T ? upper : S(upper)
    x = S == R ? x : S[x...]

    SequenceEmbedding{length(x), S}(x,lower,upper)
end

function SequenceEmbedding{R}(x::AbstractVector{A}, lower::B = x[1], upper::C = x[end]) where {A,B,C, R} 

    x = A == R ? x : R[x...]
    lower = B == R ? lower : R(lower)
    upper = C == T ? upper : R(upper)

    SequenceEmbedding{length(x), R}(x,lower,upper)
end

# Function calls 
function (S::AbstractSequenceEmbedding)(n::Int)
    S[n]
end

function (S::AbstractSequenceEmbedding)(t::Real)
    S[Int(floor(t))]
end

