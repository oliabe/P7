# Sequence Embeddings
The following makes an embeds a vector, say $x\in\mathbb{R}^n$ for some $n\in\mathbb{N}$ into the space $\mathbb{R}^{\infty}$ in the following way:

```math
X(i) = \begin{cases}l & i < 1\\
 x(i) & i \in \{1,\dots, n\}\\
 u & i > N\end{cases}
```

### SequenceEmbedding
In order to construct a sequence embedding, we use the following methods: 

```julia
X = SequenceEmbedding(x) # l = x[1], u = x[end]
X = SequenceEmbedding(x, l, u)
```
Notice that we have, by definition the three following identities: 
```julia
X[1:n] == x[1:n]
X[0] == l
X[n+1] == u
```
The same work as functions 
```julia
X.(1:n) == x[1:n]
X(0) == l
X(n+1) == u
```
Finally, we also have the following truncation for $`\varepsilon \in (0,1)`$: 
```julia
X(i + ε) == x[i] # for i in {1,..., n}
```


