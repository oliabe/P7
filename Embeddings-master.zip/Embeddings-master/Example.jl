using Embeddings
using Dates
using Plots
using Random

Random.seed!(1)

# Set up dummy data
x = DateTime(2021,1,1,0,0,0):Day(1):DateTime(2022,1,1,0,0,0)
y = cumsum(randn(length(x)))

# Make the bijection
ϕ = TimeBijector(first(x), last(x)) # Makes the time-bijector
t = map(ϕ, x) # Maps all x values to [0,1]. 

# Make the embedding 
a = 0. 
fₐ = CadlagEmbedding(y, t; lower = a) 

# Make the composition 
Z = fₐ ∘ ϕ

# Evaluate at given date
x₀ = DateTime(2021,5,1,12,34,12)
Z(x₀)  

# Plot the function on [0,1]
plot(LinRange(0,1,10000), fₐ, label = "fₐ")

# Plot the composite function on a daily grid
Π = DateTime(2021,1,1,0,0,0):Day(1):DateTime(2022,1,1,0,0,0)
plot(Π, Z.(Π), lt = :steppost, label = "Z")
scatter!([x₀], [Z(x₀)], label = "Z(x₀)")

# Zoom in
Π₀ = (x₀ - Day(3)):Second(1):(x₀ + Day(3))
plot(Π₀, Z.(Π₀), lt = :steppost, label = "Z")
scatter!([x₀], [Z(x₀)], label = "Z(x₀)")
savefig(ans,"plot_3.png")