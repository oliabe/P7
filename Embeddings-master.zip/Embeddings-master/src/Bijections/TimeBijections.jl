struct TimeBijector <: Function
    first_time::DateTime
    last_time::DateTime

    first_real::Real
    last_real::Real
end

TimeBijector(first_date::DateTime, last_date::DateTime) = TimeBijector(first_date, last_date, 0., 1.)

function (ϕ::TimeBijector)(time::DateTime)
    first_time, last_time = (ϕ.first_time, ϕ.last_time)
    first_real, last_real = (ϕ.first_real, ϕ.last_real)
    return (last_real - first_real)*(time - first_time)/(last_time - first_time) + first_real
end

function (ϕ::TimeBijector)(t::Real)
    first_time, last_time = (ϕ.first_time, ϕ.last_time)
    first_real, last_real = (ϕ.first_real, ϕ.last_real)
    return (last_time - first_time)*(t - first_real)/(last_real - first_real) + first_time
end

