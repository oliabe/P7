struct LinearEmbedding{R,T,N,E} <: Function 
    f::SequenceEmbedding{N,R}
    x::SequenceEmbedding{N,T}
end

function LinearEmbedding(f::SequenceEmbedding{N,R}, x::SequenceEmbedding{N,T}; extrapolate = true) where {N, R, T <: Real}
    I = try 
        issorted(x)
    catch e 
        error("The vector 𝑥 does not have a well-defined 'isless' method.")
    end

    if !I
        error("The domain 𝓍 is not sorted.")
    end
    if extrapolate
        return LinearEmbedding{R,T,N,:Extrapolate}(f,x)
    else
        return LinearEmbedding{R,T,N,:Interpolate}(f,x)
    end
end

LinearEmbedding(f::AbstractVector{R}, x::AbstractVector{T}; lower = f[1], upper = f[end], extrapolate = true) where {R,T <: Real} = LinearEmbedding(SequenceEmbedding(f, lower, upper),SequenceEmbedding(x); extrapolate = extrapolate)

function (L::LinearEmbedding{R,T,N, :Extrapolate})(x::Real) where {R,T <: Real,N}
    i = searchsortedlast(L.x,x)
    if (i == 0) || (i == size(L.x)[1])
        Δx = x - L.x[i]
        α = i == 0 ? (L.f[2] - L.f[1])/(L.x[2] - L.x[1]) : (L.f[i] - L.f[i-1])/(L.x[i] - L.x[i-1])
        return i == 0 ? L.f[1] + α*Δx : L.f[i] + α*Δx 
    else
        α = (x - L.x[i])/(L.x[i+1] - L.x[i])
        return α*L.f[i+1] + (1-α)*L.f[i]
    end
end

function (L::LinearEmbedding{R,T,N, :Interpolate})(x::Real) where {R,T <: Real,N}
    i = searchsortedlast(L.x,x)
    if (i == 0) || (i == size(L.x)[1])
        return L.f[i]
    else
        α = (x - L.x[i])/(L.x[i+1] - L.x[i])
        return α*L.f[i+1] + (1-α)*L.f[i]
    end
end

