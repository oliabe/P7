abstract type SimpleEmbedding{R,T} <: Function end

# Cadlag Embeddings 
struct CadlagEmbedding{R,T, N} <: SimpleEmbedding{T,R}
    f::SequenceEmbedding{N, R}
    x::AbstractVector{T}

    CadlagEmbedding(f::SequenceEmbedding{N, R}, x::AbstractVector{T}) where {N, R, T} = begin
        I = try 
            issorted(x)
        catch e 
            error("The vector 𝑥 does not have a well-defined 'isless' method.")
        end

        if !I
            error("The domain 𝓍 is not sorted.")
        end

        if N != length(x) 
            error("The vectors 𝑓 and 𝑥 are not of the same size.")
        end

        new{R,T,N}(f,x)
    end
end

CadlagEmbedding(f::AbstractVector{R}, x::AbstractVector{T}; lower = f[1]) where {R,T} = CadlagEmbedding(SequenceEmbedding(f, lower),x)

function (C::CadlagEmbedding)(x::R) where {R <: Real}
    C.f[searchsortedlast(C.x,x)]
end

# CagladEmbeddings 
struct CagladEmbedding{R,T, N} <: SimpleEmbedding{T,R}
    f::SequenceEmbedding{N, R}
    x::AbstractVector{T}

    CagladEmbedding(f::SequenceEmbedding{N, R}, x::AbstractVector{T}) where {N, R, T} = begin
        I = try 
            issorted(x)
        catch e 
            error("The vector 𝑥 does not have a well-defined 'isless' method.")
        end

        if !I
            error("The domain 𝓍 is not sorted.")
        end

        if N != length(x) 
            error("The vectors 𝑓 and 𝑥 are not of the same size.")
        end

        new{R,T,N}(f,x)
    end
end

CagladEmbedding(f::AbstractVector{R}, x::AbstractVector{T}, lower = f[1]) where {R,T} = CagladEmbedding(SequenceEmbedding(f, lower),x)

function (C::CagladEmbedding)(x::R) where {R <: Real}
    C.f[searchsortedlast(C.x,x, lt = ≤)]
end

