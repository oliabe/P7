# Linear Embedding
While the name suggests it, the embedding is not _actually_ linear, but rather piecewise linear; it corresponds to linear interpolation. Therefore, a dataset $\{(y_i,t_i)\}_{i=1}^n \subset \mathbb{R}^n \times \mathbb{R}^n$ for some $n\in\mathbb{N}$ is embedded by considering the function 

```math
f(t) = l(t)\mathbb{I}_{(-\infty,t_1)} + \sum_{i=1}^{n-1} \left(\left(1 - \frac{t - t_i}{t_{i+1} - t_i}\right)y_i + \frac{t - t_i}{t_{i+1} - t_i}y_{i+1}\right)\mathbb{I}_{[t_i,t_{i+1})}(t) + u(t)\mathbb{I}_{(t_n, \infty)}(t).
```

Currently, only two types of extrapolation functions $l$ and $u$ are considered. Namely, constant extrapolation and or linear extrapolation. Please, refer to the snippet below for contructors:

```julia
f = LinearEmbedding(y,t) # Defaults to linear extrapolation.
f = LinearEmbedding(y,t; extrapolate = false) # Defaults to constant extrapolation for convenience although the name is misleading 🤦‍♂️
```
